﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Prog6212PoeDraft.Model;

namespace Prog6212PoeDraft.Pages.Reminders
{
    public class IndexModel : PageModel
    {
        private readonly Prog6212PoeDraft.Model.LoginContext _context;

        public IndexModel(Prog6212PoeDraft.Model.LoginContext context)
        {
            _context = context;
        }

        public IList<Reminder> Reminder { get;set; }

        public async Task OnGetAsync()
        {
            Reminder = await _context.Reminder.Where(x => x.UserName == User.Identity.Name).ToListAsync();
        }
    }
}
