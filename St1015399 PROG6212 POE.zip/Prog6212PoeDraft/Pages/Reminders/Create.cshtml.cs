﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Prog6212PoeDraft.Model;

namespace Prog6212PoeDraft.Pages.Reminders
{
    public class CreateModel : PageModel
    {
        private readonly Prog6212PoeDraft.Model.LoginContext _context;

        public CreateModel(Prog6212PoeDraft.Model.LoginContext context)
        {
            _context = context;
        }

        public List<SelectListItem> combo { get; set; }
        public IActionResult OnGet()
        {
            combo = new SelectList(_context.Module.Where(t => t.UserName == User.Identity.Name), "ModuleCode", "ModuleCode").ToList();
            return Page();
        }

        [BindProperty]
        public Reminder Reminder { get; set; }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            Reminder.UserName = User.Identity.Name;
            _context.Reminder.Add(Reminder);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
