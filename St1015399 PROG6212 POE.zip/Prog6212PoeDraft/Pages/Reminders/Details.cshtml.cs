﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Prog6212PoeDraft.Model;

namespace Prog6212PoeDraft.Pages.Reminders
{
    public class DetailsModel : PageModel
    {
        private readonly Prog6212PoeDraft.Model.LoginContext _context;

        public DetailsModel(Prog6212PoeDraft.Model.LoginContext context)
        {
            _context = context;
        }

        public Reminder Reminder { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Reminder = await _context.Reminder.FirstOrDefaultAsync(m => m.ReminderId == id);

            if (Reminder == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
