﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Prog6212PoeDraft.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Prog6212PoeDraft.Pages
{
  
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly LoginContext context;

        public IndexModel(ILogger<IndexModel> logger,LoginContext context)
        {
            _logger = logger;
            this.context = context;
        }

        [BindProperty]
        public string Days { get; set; }
        public string modCode { get; set; }

        public void OnGet()
        {
            Days = DateTime.Today.DayOfWeek.ToString();


            modCode = "No Module";
            var Search = from rec in context.Reminder
                            where rec.UserName == User.Identity.Name
                            select rec;

            var day = Search.ToList();

            if (Search != null || (day.Any()))
            {
                modCode = "";
                foreach (Reminder tb in day)
                {
                 modCode += tb.ModuleCode + ","; //get module for this day
                    
                }

            }

        }
    }
}
