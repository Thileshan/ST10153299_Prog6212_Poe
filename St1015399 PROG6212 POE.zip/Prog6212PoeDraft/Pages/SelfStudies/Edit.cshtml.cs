﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Prog6212PoeDraft.Model;

namespace Prog6212PoeDraft.Pages.SelfStudies
{
    public class EditModel : PageModel
    {
        private readonly Prog6212PoeDraft.Model.LoginContext _context;

        public EditModel(Prog6212PoeDraft.Model.LoginContext context)
        {
            _context = context;
        }

        [BindProperty]
        public SelfStudy SelfStudy { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            SelfStudy = await _context.SelfStudy.FirstOrDefaultAsync(m => m.studyID == id);

            if (SelfStudy == null)
            {
                return NotFound();
            }
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(SelfStudy).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SelfStudyExists(SelfStudy.studyID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool SelfStudyExists(int id)
        {
            return _context.SelfStudy.Any(e => e.studyID == id);
        }
    }
}
