﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Prog6212PoeDraft.Model;
using Prog6212PoeLibrary;

namespace Prog6212PoeDraft.Pages.SelfStudies
{
    public class CreateModel : PageModel
    {
        private readonly Prog6212PoeDraft.Model.LoginContext _context;

        public CreateModel(Prog6212PoeDraft.Model.LoginContext context)
        {
            _context = context;
        }

        public List<SelectListItem> Box { get; set; }
        public IActionResult OnGet()
        {
           Box = new SelectList(_context.Module.Where(t => t.UserName == User.Identity.Name), "ModuleCode", "ModuleCode").ToList();
           return Page();
       }

        [BindProperty]
        public SelfStudy SelfStudy { get; set; }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUDs
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }


            DateTime modStartDate = DateTime.Now;
            var query = _context.Module.Where(t => t.UserName == User.Identity.Name && t.ModuleCode == SelfStudy.Code).ToList();
            foreach (Module m in query)
            {
                modStartDate = m.StartDate;
            }

            SelfStudy.WorkWeek = Calculate.workWeek(SelfStudy.DateOfStudy, modStartDate);
            SelfStudy.UserName = User.Identity.Name;
            _context.SelfStudy.Add(SelfStudy);
            await _context.SaveChangesAsync();
            return RedirectToPage("./Index");

           


        }
    }
}
