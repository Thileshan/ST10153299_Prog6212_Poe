﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Prog6212PoeDraft.Model;

namespace Prog6212PoeDraft.Pages.SelfStudies
{
    public class DeleteModel : PageModel
    {
        private readonly Prog6212PoeDraft.Model.LoginContext _context;

        public DeleteModel(Prog6212PoeDraft.Model.LoginContext context)
        {
            _context = context;
        }

        [BindProperty]
        public SelfStudy SelfStudy { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            SelfStudy = await _context.SelfStudy.FirstOrDefaultAsync(m => m.studyID == id);

            if (SelfStudy == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            SelfStudy = await _context.SelfStudy.FindAsync(id);

            if (SelfStudy != null)
            {
                _context.SelfStudy.Remove(SelfStudy);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
