﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Prog6212PoeDraft.Model;
using Prog6212PoeLibrary;

namespace Prog6212PoeDraft.Pages.Modules
{
    public class CreateModel : PageModel
    {
        private readonly Prog6212PoeDraft.Model.LoginContext _context;

        public CreateModel(Prog6212PoeDraft.Model.LoginContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Module Module { get; set; }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var search = from rec in _context.Module
                         where rec.UserName == User.Identity.Name && rec.ModuleCode == Module.ModuleCode
                         select rec;
            var list = search.ToList();
            // checks to see if the module already exists
            if (search == null ||(!list.Any()))
            {
                // gets the user name for the currently logged on user
                Module.UserName = User.Identity.Name; 
                // gets the calculation from the library dll
                Module.HrsPerWeek = Calculate.CalcHoursPerWeek(Module.Credits, Module.Weeks, Module.ClassHours);
                _context.Module.Add(Module);
                // saves to the database
                await _context.SaveChangesAsync();

                return RedirectToPage("./Index");
            }
             
            return Page();
        } 
    }
}
