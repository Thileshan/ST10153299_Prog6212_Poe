﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Prog6212PoeDraft.Model;
using Prog6212PoeLibrary;

namespace Prog6212PoeDraft.Pages.Modules
{
   
    public class DetailsModel : PageModel
    {
        private readonly Prog6212PoeDraft.Model.LoginContext _context;

        public DetailsModel(Prog6212PoeDraft.Model.LoginContext context)
        {
            _context = context;
        }

        public Module Module { get; set; }

        public int remainingHours { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Module = await _context.Module.FirstOrDefaultAsync(m => m.ModuleID == id);

            if (Module == null)
            {
                return NotFound();
            }

            DateTime startDate = DateTime.Now;
            int ssHours = 0;
            int sum = 0;
            var query = _context.Module.Where(t => t.UserName == User.Identity.Name && t.ModuleCode == Module.ModuleCode).ToList();
            foreach (Module m in query)
            {
                startDate = m.StartDate;
                ssHours = m.HrsPerWeek;
            }



            int currentweek = Calculate.currentWeek(startDate);
            var query1 = _context.SelfStudy.Where(a => a.UserName == User.Identity.Name && a.Code == Module.ModuleCode).ToList();
            foreach (SelfStudy s in query1)
            {
                if (currentweek == s.WorkWeek)
                {
                    sum += s.HoursStudied;
                }

            }
            remainingHours = ssHours - sum;




            return Page();
        }
    }
}
