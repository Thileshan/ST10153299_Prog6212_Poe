﻿using System.ComponentModel.DataAnnotations;

namespace Prog6212PoeDraft.ViewModel
{
    public class Register
    {
        [Required]
        [DataType(DataType.EmailAddress)]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Compare(nameof(Password),ErrorMessage ="The Passwords Do Not Match")]
        public string Confirm { get; set; }
    }
}
