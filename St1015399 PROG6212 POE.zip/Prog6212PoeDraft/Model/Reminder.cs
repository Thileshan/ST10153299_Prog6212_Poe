﻿using System.ComponentModel.DataAnnotations;

namespace Prog6212PoeDraft.Model
{
    public class Reminder
    {
        [Key]
        [Required]
        public int ReminderId { get; set; }

        public string UserName { get; set; }
        [Required]
        public string Days { get; set; }
        public string ModuleCode { get; set; }
        


    }
}
