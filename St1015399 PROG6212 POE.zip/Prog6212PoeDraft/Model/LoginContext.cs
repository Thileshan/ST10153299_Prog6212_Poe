﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Prog6212PoeDraft.Model;

namespace Prog6212PoeDraft.Model
{
    public class LoginContext : IdentityDbContext
    {
        public LoginContext(DbContextOptions<LoginContext>options): base(options)
        {

        }
        public DbSet<Prog6212PoeDraft.Model.Module> Module { get; set; }
        public DbSet<Prog6212PoeDraft.Model.SelfStudy> SelfStudy { get; set; }
        public DbSet<Prog6212PoeDraft.Model.Reminder> Reminder { get; set; }

    }
}
