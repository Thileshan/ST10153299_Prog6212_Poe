﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Prog6212PoeDraft.Model
{
    public class Module
    {
        [Key]
        
        public int ModuleID { get; set; }
       
        public string UserName { get; set; }
       
        public string ModuleName { get; set; }

        public string ModuleCode { get; set; }

        public int Credits { get; set; }
        
        public int ClassHours { get; set; }
        
        public int Weeks { get; set; }
      
        public DateTime StartDate { get; set; }
      
        public int HrsPerWeek { get; set; }
    }

}
