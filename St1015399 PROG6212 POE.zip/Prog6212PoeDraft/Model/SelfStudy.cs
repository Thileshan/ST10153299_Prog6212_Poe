﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Prog6212PoeDraft.Model
{
    public class SelfStudy
    {
        [Key]
        
        public int studyID { get; set; }
    
        public string UserName { get; set; }
       
        public DateTime DateOfStudy { get; set; }
       
        public string Code { get; set; }
       
        public int HoursStudied { get; set; }
       
        public int WorkWeek { get; set; }
    }
}
